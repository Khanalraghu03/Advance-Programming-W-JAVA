

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;


/**Class: Encrypt13Tester.java
 * @author Rubilacxe
 * @version 1.0
 * Course: ITEC3150 Spring 2019
 * Written: Feb 12, 2019
 * 
 * This class: creates a GridPane with different labels and TextFields. Sets the Lambda expression which then calls the Encrypt13 class
 *
 * Purpose: Create and Test the GridPane to display with JavaFX.
 */
public class Encrypt13Tester extends Application 
{
	@Override
	public void start(Stage primaryStage) 
	{
		try 
		{
			//Create GridPane 
			GridPane root = new GridPane();
			//Label that contains the text OriginalMessage
			Label oMsg = new Label("Original Message ");
			root.add(oMsg, 0, 0);
			//TextField used for user to enter String for encryption
			TextField enterMsg = new TextField();
			root.add(enterMsg, 1, 0);
			//Label that contains the text Encrypted Message
			Label nMsg = new Label("Encrypted Message ");
			root.add(nMsg, 0, 1);
			//Blank label that will display the encrypted message once the user presses enter
			Label encrypted = new Label();
			root.add(encrypted, 1, 1);
			//Lambda expression that controls the TextField enterMsg, once user finishes the message and presses enter, the message gets encrypted in the Encrypt13 class.
			enterMsg.setOnKeyReleased(e -> {
				if (e.getCode().equals(KeyCode.ENTER))
				{
					Encrypt13 en = new Encrypt13();
					String txt = enterMsg.getText();
					String rText = en.encrypt(txt);
					encrypted.setText(rText);
				}
			});
			//Sets the GridPane into the scene, the size of the scene, title, and displays the JavaFX program.
			Scene scene = new Scene(root,300,75);
			primaryStage.setTitle("Encrypt by Rotating 13");
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args) 
	{
		launch(args);
	}
}
