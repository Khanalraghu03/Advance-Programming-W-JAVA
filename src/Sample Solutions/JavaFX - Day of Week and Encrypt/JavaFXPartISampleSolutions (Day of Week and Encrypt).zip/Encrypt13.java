/**Class: Encrypt13.java
 * @author Rubilacxe
 * @version 1.0
 * Course: ITEC3150 Spring 2019
 * Written: Feb 12, 2019
 * 
 * This class: Takes in the a String, converts to a char[] in order to compare each character,
 * Once a character is determined as lowercase or uppercase, the program either adds or subtracts 13 from the ASCII Table and sets the value into a separate char[].
 * The second char[] is converted back to a String that is the encrypted message. 
 *
 * Purpose: Encrypt and return inputed data as a String.
 */
public class Encrypt13
{
	private char[] characters;
	private char[] encryptedCharacters;	
	
	public String encrypt(String text)
	{
		characters = text.toCharArray();
		encryptedCharacters = new char[characters.length];

		for(int index = 0; index < characters.length; index ++)
		{
			//Checks if character at index is lower case value
			if(Character.isLowerCase(characters[index]))
			{
				if(characters[index] >= 'a' && characters[index] <= 'm')
				{
					encryptedCharacters[index] = (char) (characters[index] + 13);
				}

				else if(characters[index] >= 'n' && characters[index] <= 'z')
				{
					encryptedCharacters[index] = (char) (characters[index] - 13);
				}
			}

			else if(Character.isUpperCase(characters[index]))
			{
				//Checks if character at index is upper case value
				if(characters[index] >='A' && characters[index] <= 'M')
				{
					encryptedCharacters[index] = (char) (characters[index] + 13);
				}

				else if (characters[index] >='N' && characters[index] <= 'Z')
				{
					encryptedCharacters[index] = (char) (characters[index] - 13);
				}
			}

			else
			{
				//If the character is not a lowercase or uppercase letter, the program does not change the variable.
				encryptedCharacters[index] = characters[index];
			}
		}
		String encryptedText = new String(encryptedCharacters);
		return encryptedText;
	}
}
