import java.util.Scanner;

/**Class: Encrypt13Tester.java
 * @author ITEC 3150
 * @version 1.0
 * Course: ITEC3150 Spring 2019
 * Written: Feb 12, 2019
 * 
 * This class: Allows user to enter a message to encrypt via scanner
 *
 * Purpose: Show that the algorithm works with any client - demoes MVC
 */
public class Encrypt13Tester2 
{



	public static void main(String[] args) 
	{
		Encrypt13 en = new Encrypt13();
		System.out.println("Encrypt by Rotating 13");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the string you would like to encrypt: ");		
		System.out.println("Encrypted message: " + en.encrypt(sc.nextLine()));
		sc.close();
	}
}
